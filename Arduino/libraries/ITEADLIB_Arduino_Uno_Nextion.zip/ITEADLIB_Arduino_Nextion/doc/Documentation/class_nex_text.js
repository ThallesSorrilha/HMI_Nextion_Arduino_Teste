var class_nex_text =
[
    [ "NexText", "class_nex_text.html#a38b4dd752d39bfda4ef7642b43ded91a", null ],
    [ "Get_background_color_bco", "class_nex_text.html#aec8d21665688ba80f3136a1f5e23fef5", null ],
    [ "Get_background_crop_picc", "class_nex_text.html#ae44393fb20ba449bf088dbd0758b4219", null ],
    [ "Get_background_image_pic", "class_nex_text.html#aed07b3988fe2c4ec332727bb245e49a5", null ],
    [ "Get_font_color_pco", "class_nex_text.html#a860af363c6de6180ef356cad31936185", null ],
    [ "Get_place_xcen", "class_nex_text.html#a510a937a104b41859badc220a8ba39fb", null ],
    [ "Get_place_ycen", "class_nex_text.html#a9bd42732e37497a8fb44ece94b39285c", null ],
    [ "getFont", "class_nex_text.html#adc480199a2b396811aa0c14928b592c8", null ],
    [ "getText", "class_nex_text.html#a9cf417b2f25df2872492c55bdc9f5b30", null ],
    [ "Set_background_color_bco", "class_nex_text.html#a1b1586e5e66d76a4f8f5c40b0986f471", null ],
    [ "Set_background_crop_picc", "class_nex_text.html#a3727463a4fc0e1df978cd8fc7d1103ed", null ],
    [ "Set_background_image_pic", "class_nex_text.html#ab2c85ac7d5184e124b0cd724028c1915", null ],
    [ "Set_font_color_pco", "class_nex_text.html#ab59df7e777198eefb422ba2081d0cfce", null ],
    [ "Set_place_xcen", "class_nex_text.html#ab94a4b8505a9bfdf8fb4cb8cb32a1763", null ],
    [ "Set_place_ycen", "class_nex_text.html#a0f8ad9780c8145569da6736d0ee494e4", null ],
    [ "setFont", "class_nex_text.html#a5dd7fdda945a76033ef8fe8dc68e3e52", null ],
    [ "setText", "class_nex_text.html#a19589b32c981436a1bbcfe407bc766e3", null ]
];