var class_nex_crop =
[
    [ "NexCrop", "class_nex_crop.html#a1a3a195d3da05cb832f91a2ef43f27d3", null ],
    [ "Get_background_crop_picc", "class_nex_crop.html#a19f824bea045bab4cc1afc5950259247", null ],
    [ "getPic", "class_nex_crop.html#a2cbfe125182626965dd530f14ab55885", null ],
    [ "Set_background_crop_picc", "class_nex_crop.html#aa85a69de5055c29f0a85406d10806bfe", null ],
    [ "setPic", "class_nex_crop.html#aac34fc2f8ead1e330918089ea8a339db", null ]
];